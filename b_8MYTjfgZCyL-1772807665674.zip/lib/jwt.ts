import jwt, { SignOptions, VerifyOptions } from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

export interface JWTPayload {
  userId: string;
  email: string;
  role: 'student' | 'mentor' | 'admin';
  iat?: number;
  exp?: number;
}

export const jwtUtils = {
  sign(payload: Omit<JWTPayload, 'iat' | 'exp'>, expiresIn: SignOptions['expiresIn'] = '7d'): string {
    const options: SignOptions = {
      expiresIn,
      algorithm: 'HS256',
    };
    return jwt.sign(payload, JWT_SECRET, options);
  },

  verify(token: string): JWTPayload | null {
    try {
      const options: VerifyOptions = {
        algorithms: ['HS256'],
      };
      const decoded = jwt.verify(token, JWT_SECRET, options);
      return decoded as JWTPayload;
    } catch (error) {
      return null;
    }
  },

  decode(token: string): JWTPayload | null {
    try {
      const decoded = jwt.decode(token);
      return decoded as JWTPayload | null;
    } catch (error) {
      return null;
    }
  },
};
