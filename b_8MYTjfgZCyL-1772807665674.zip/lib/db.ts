import bcrypt from 'bcryptjs';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'student' | 'mentor' | 'admin';
  createdAt: Date;
  averageScore: number;
}

class Database {
  private users: Map<string, User> = new Map();
  private emailIndex: Map<string, string> = new Map();

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Empty - no demo users
  }

  async createUser(input: {
    name: string;
    email: string;
    password: string;
    role: 'student' | 'mentor' | 'admin';
  }): Promise<User> {
    // Check if email already exists
    if (this.emailIndex.has(input.email.toLowerCase())) {
      throw new Error('Email already in use');
    }

    // Validate inputs
    if (!input.name || input.name.trim().length === 0) {
      throw new Error('Name is required');
    }

    if (!input.email || !this.isValidEmail(input.email)) {
      throw new Error('Valid email is required');
    }

    if (!input.password || input.password.length < 6) {
      throw new Error('Password must be at least 6 characters');
    }

    if (!['student', 'mentor', 'admin'].includes(input.role)) {
      throw new Error('Invalid role');
    }

    // Hash password
    const passwordHash = await bcrypt.hash(input.password, 10);

    // Create user
    const user: User = {
      id: this.generateId(),
      name: input.name.trim(),
      email: input.email.toLowerCase(),
      passwordHash,
      role: input.role,
      createdAt: new Date(),
      averageScore: 75,
    };

    // Store user
    this.users.set(user.id, user);
    this.emailIndex.set(user.email, user.id);

    return user;
  }

  async findUserByEmail(email: string): Promise<User | null> {
    const userId = this.emailIndex.get(email.toLowerCase());
    if (!userId) return null;
    const user = this.users.get(userId);
    return user || null;
  }

  async findUserById(id: string): Promise<User | null> {
    const user = this.users.get(id);
    return user || null;
  }

  async verifyPassword(user: User, password: string): Promise<boolean> {
    return bcrypt.compare(password, user.passwordHash);
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private generateId(): string {
    return `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Singleton instance
export const db = new Database();
