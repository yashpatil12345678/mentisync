import { serialize, parse } from 'cookie';
import { NextApiRequest, NextApiResponse } from 'next';

const TOKEN_COOKIE_NAME = 'auth_token';
const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 7 * 24 * 60 * 60, // 7 days
};

export const cookieUtils = {
  setToken(res: NextApiResponse, token: string): void {
    const cookie = serialize(TOKEN_COOKIE_NAME, token, COOKIE_OPTIONS);
    res.setHeader('Set-Cookie', cookie);
  },

  getToken(req: NextApiRequest): string | null {
    const cookies = parse(req.headers.cookie || '');
    return cookies[TOKEN_COOKIE_NAME] || null;
  },

  clearToken(res: NextApiResponse): void {
    const cookie = serialize(TOKEN_COOKIE_NAME, '', {
      ...COOKIE_OPTIONS,
      maxAge: 0,
    });
    res.setHeader('Set-Cookie', cookie);
  },
};
