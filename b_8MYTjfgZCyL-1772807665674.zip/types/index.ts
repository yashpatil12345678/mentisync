export type UserRole = 'student' | 'mentor' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  averageScore?: number;
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

export interface Session {
  id: string;
  title: string;
  date: string;
  duration: number;
  status: 'completed' | 'scheduled' | 'cancelled';
  mentor?: string;
  student?: string;
}

export interface PerformanceData {
  date: string;
  score: number;
}

export interface DashboardStats {
  totalSessions: number;
  completedSessions: number;
  averageScore: number;
  progress: number;
}
