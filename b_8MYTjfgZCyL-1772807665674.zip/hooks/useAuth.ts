import { useState, useEffect, useCallback } from 'react';
import { authUtils, User as AuthUser, LoginInput, SignupInput } from '../utils/auth';

export interface User extends AuthUser {
  avatar?: string;
}

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const currentUser = await authUtils.getCurrentUser();
        if (currentUser) {
          setUser({
            ...currentUser,
            avatar: currentUser.name
              .split(' ')
              .map((n) => n[0])
              .join('')
              .toUpperCase(),
          });
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = useCallback(async (input: LoginInput) => {
    setError(null);
    try {
      const result = await authUtils.login(input);
      if (result.success && result.user) {
        const userWithAvatar: User = {
          ...result.user,
          avatar: result.user.name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .toUpperCase(),
        };
        setUser(userWithAvatar);
        return { success: true };
      } else {
        setError(result.error || 'Login failed');
        return { success: false, error: result.error };
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Login failed';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  }, []);

  const signup = useCallback(async (input: SignupInput) => {
    setError(null);
    try {
      const result = await authUtils.signup(input);
      if (result.success && result.user) {
        const userWithAvatar: User = {
          ...result.user,
          avatar: result.user.name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .toUpperCase(),
        };
        setUser(userWithAvatar);
        return { success: true };
      } else {
        setError(result.error || 'Signup failed');
        return { success: false, error: result.error };
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Signup failed';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  }, []);

  const logout = useCallback(async () => {
    setError(null);
    try {
      const result = await authUtils.logout();
      if (result.success) {
        setUser(null);
        return { success: true };
      } else {
        setError(result.error || 'Logout failed');
        return { success: false, error: result.error };
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Logout failed';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    }
  }, []);

  return {
    user,
    isLoading,
    error,
    login,
    logout,
    signup,
    isAuthenticated: !!user,
  };
};
