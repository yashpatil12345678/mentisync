import React from 'react';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { Bell, CheckCircle, AlertCircle, MessageCircle } from 'lucide-react';

export default function Notifications() {
  const notifications = [
    {
      id: 1,
      type: 'message',
      title: 'New message from Sarah',
      message: 'Sarah sent you a message about your progress.',
      timestamp: '2 hours ago',
      icon: MessageCircle,
      read: false,
    },
    {
      id: 2,
      type: 'session',
      title: 'Session scheduled',
      message: 'Your mentoring session with Dr. Chen has been scheduled.',
      timestamp: '1 day ago',
      icon: CheckCircle,
      read: true,
    },
    {
      id: 3,
      type: 'alert',
      title: 'Goal reminder',
      message: 'Remember to complete your learning goal for this week.',
      timestamp: '3 days ago',
      icon: AlertCircle,
      read: true,
    },
  ];

  return (
    <ProtectedRoute>
      <DashboardLayout title="Notifications">
        <div className="max-w-3xl space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-2xl font-bold text-gray-900">
              <Bell className="h-6 w-6" />
              Notifications
            </h2>
            <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
              Mark all as read
            </button>
          </div>

          <div className="space-y-3">
            {notifications.map((notif) => {
              const Icon = notif.icon;
              return (
                <div
                  key={notif.id}
                  className={`rounded-lg border p-4 ${
                    notif.read
                      ? 'border-gray-200 bg-white'
                      : 'border-blue-200 bg-blue-50'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`rounded-full p-2 ${
                      notif.read ? 'bg-gray-100' : 'bg-blue-100'
                    }`}>
                      <Icon className={`h-5 w-5 ${
                        notif.read ? 'text-gray-600' : 'text-blue-600'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${
                        notif.read ? 'text-gray-900' : 'text-blue-900'
                      }`}>
                        {notif.title}
                      </p>
                      <p className={`text-sm ${
                        notif.read ? 'text-gray-600' : 'text-blue-800'
                      }`}>
                        {notif.message}
                      </p>
                      <p className="mt-1 text-xs text-gray-500">{notif.timestamp}</p>
                    </div>
                    {!notif.read && (
                      <div className="h-2 w-2 rounded-full bg-blue-600"></div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
