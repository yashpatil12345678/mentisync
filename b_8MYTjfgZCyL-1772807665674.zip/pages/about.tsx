import React from 'react';
import Link from 'next/link';
import { Users, Target, BookOpen, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="sticky top-0 border-b border-gray-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600">
                <span className="text-sm font-bold text-white">MS</span>
              </div>
              <span className="text-xl font-bold text-gray-900">MentiSync</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login" className="text-gray-600 hover:text-gray-900 font-medium">
                Sign In
              </Link>
              <Link
                href="/signup"
                className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 font-medium"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto max-w-4xl px-4 py-20 sm:px-6 lg:px-8">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">About MentiSync</h1>
        <p className="text-xl text-gray-600">
          MentiSync is a platform dedicated to connecting mentors and students for meaningful growth and learning.
        </p>
      </section>

      {/* Mission */}
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
        <p className="text-lg text-gray-600 mb-6">
          We believe that everyone deserves access to quality mentorship. Our mission is to break down barriers and create opportunities for meaningful connections between experienced professionals and those seeking to grow.
        </p>
      </section>

      {/* Values */}
      <section className="bg-gray-100 py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Our Values</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="rounded-lg bg-white p-8">
              <Users className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Community</h3>
              <p className="text-gray-600">
                We believe in the power of community and the value of human connection.
              </p>
            </div>
            <div className="rounded-lg bg-white p-8">
              <Target className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Growth</h3>
              <p className="text-gray-600">
                We are committed to helping individuals reach their full potential.
              </p>
            </div>
            <div className="rounded-lg bg-white p-8">
              <BookOpen className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Learning</h3>
              <p className="text-gray-600">
                Education and continuous learning are at the heart of what we do.
              </p>
            </div>
            <div className="rounded-lg bg-white p-8">
              <Heart className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-3">Impact</h3>
              <p className="text-gray-600">
                We measure success by the positive impact we have on people's lives.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Ready to Get Started?</h2>
        <Link
          href="/signup"
          className="inline-block rounded-lg bg-blue-600 px-8 py-3 text-white hover:bg-blue-700 font-semibold"
        >
          Join MentiSync Today
        </Link>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white py-8 px-4 sm:px-6 lg:px-8 text-center text-gray-600 text-sm">
        <p>&copy; 2024 MentiSync. All rights reserved.</p>
      </footer>
    </div>
  );
}
