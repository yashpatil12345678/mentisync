import React, { useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { StatCard } from '../components/dashboard/StatCard';
import { PerformanceChart } from '../components/dashboard/PerformanceChart';
import { SessionCard } from '../components/dashboard/SessionCard';
import { AdaptiveAlertCard } from '../components/dashboard/AdaptiveAlertCard';
import { dataUtils } from '../utils/data';
import { Users, TrendingUp, Clock, Star } from 'lucide-react';

export default function MentorDashboard() {
  const { user } = useAuth();
  const performanceData = useMemo(() => dataUtils.getPerformanceData(), []);
  const sessions = useMemo(() => dataUtils.getSessions('mentor'), []);
  const stats = useMemo(
    () => dataUtils.getDashboardStats('mentor', user?.averageScore || 90),
    [user?.averageScore]
  );

  return (
    <ProtectedRoute allowedRoles={['mentor']}>
      <DashboardLayout title="Mentor Dashboard">
        <div className="space-y-8">
          {/* Adaptive Alert */}
          <AdaptiveAlertCard averageScore={user?.averageScore || 90} />

          {/* Stats Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Active Mentees"
              value={8}
              icon={Users}
              color="blue"
            />
            <StatCard
              label="Sessions Completed"
              value={stats.completedSessions}
              icon={TrendingUp}
              color="green"
              change={{
                value: 18,
                positive: true,
              }}
            />
            <StatCard
              label="Average Rating"
              value={`${stats.averageScore}%`}
              icon={Star}
              color="purple"
            />
            <StatCard
              label="Response Time"
              value="2h"
              icon={Clock}
              color="orange"
            />
          </div>

          {/* Charts and Stats */}
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Performance Chart */}
            <div className="lg:col-span-2">
              <PerformanceChart data={performanceData} />
            </div>

            {/* Mentor Stats */}
            <div className="space-y-4">
              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900">Your Impact</h3>
                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Mentees</span>
                    <span className="font-semibold text-gray-900">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Success Rate</span>
                    <span className="font-semibold text-gray-900">92%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Avg Rating</span>
                    <span className="font-semibold text-gray-900">4.8/5</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Hours Invested</span>
                    <span className="font-semibold text-gray-900">156h</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Upcoming Sessions */}
          <div id="students">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Scheduled Sessions</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {sessions.slice(0, 3).map((session) => (
                <SessionCard
                  key={session.id}
                  session={session}
                />
              ))}
            </div>
          </div>

          {/* All Sessions */}
          <div id="analytics">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">All Sessions</h2>
            <div className="space-y-3">
              {sessions.map((session) => (
                <SessionCard
                  key={session.id}
                  session={session}
                  variant="compact"
                />
              ))}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
