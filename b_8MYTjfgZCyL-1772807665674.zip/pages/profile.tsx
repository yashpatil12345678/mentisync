import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { User, Mail, Briefcase, MapPin, Edit2 } from 'lucide-react';

export default function Profile() {
  const { user } = useAuth();

  return (
    <ProtectedRoute>
      <DashboardLayout title="Profile">
        <div className="max-w-3xl space-y-6">
          {/* Profile Header */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-6">
                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-blue-600">
                  <span className="text-4xl font-bold text-white">{user?.avatar}</span>
                </div>
                <div>
                  <h2 className="text-3xl font-bold text-gray-900">{user?.name}</h2>
                  <p className="text-lg capitalize text-gray-600">{user?.role}</p>
                  <p className="mt-2 text-sm text-gray-500">Member since January 2024</p>
                </div>
              </div>
              <button className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700 transition-colors">
                <Edit2 className="h-4 w-4" />
                Edit Profile
              </button>
            </div>
          </div>

          {/* Profile Information */}
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
            <h3 className="mb-6 text-xl font-bold text-gray-900">Profile Information</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-4 border-b border-gray-200 pb-4">
                <User className="h-5 w-5 text-gray-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">Full Name</p>
                  <p className="font-medium text-gray-900">{user?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 border-b border-gray-200 pb-4">
                <Mail className="h-5 w-5 text-gray-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">Email</p>
                  <p className="font-medium text-gray-900">{user?.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 border-b border-gray-200 pb-4">
                <Briefcase className="h-5 w-5 text-gray-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">Role</p>
                  <p className="capitalize font-medium text-gray-900">{user?.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <MapPin className="h-5 w-5 text-gray-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">Location</p>
                  <p className="font-medium text-gray-900">San Francisco, CA</p>
                </div>
              </div>
            </div>
          </div>

          {/* Performance */}
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
            <h3 className="mb-6 text-xl font-bold text-gray-900">Performance</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="font-medium text-gray-900">Average Score</p>
                <p className="text-lg font-bold text-blue-600">{user?.averageScore}%</p>
              </div>
              <div className="h-2 w-full rounded-full bg-gray-200">
                <div
                  className="h-2 rounded-full bg-blue-600"
                  style={{ width: `${user?.averageScore || 75}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
