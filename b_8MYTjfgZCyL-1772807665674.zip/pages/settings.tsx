import React, { useState } from 'react';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { Settings as SettingsIcon, Bell, Shield, Eye } from 'lucide-react';

export default function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [twoFactor, setTwoFactor] = useState(false);

  return (
    <ProtectedRoute>
      <DashboardLayout title="Settings">
        <div className="max-w-2xl space-y-6">
          {/* General Settings */}
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
            <div className="mb-6 flex items-center gap-2">
              <SettingsIcon className="h-6 w-6 text-gray-900" />
              <h2 className="text-2xl font-bold text-gray-900">General Settings</h2>
            </div>

            <div className="space-y-4">
              {/* Notification Settings */}
              <div className="flex items-center justify-between border-b border-gray-200 pb-4">
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Push Notifications</p>
                    <p className="text-sm text-gray-600">Receive alerts about sessions and messages</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={notifications}
                  onChange={(e) => setNotifications(e.target.checked)}
                  className="h-5 w-5"
                />
              </div>

              {/* Email Alerts */}
              <div className="flex items-center justify-between border-b border-gray-200 pb-4">
                <div className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Email Alerts</p>
                    <p className="text-sm text-gray-600">Get weekly summaries and important updates</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={emailAlerts}
                  onChange={(e) => setEmailAlerts(e.target.checked)}
                  className="h-5 w-5"
                />
              </div>

              {/* Two Factor */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Two-Factor Authentication</p>
                    <p className="text-sm text-gray-600">Enhanced security for your account</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={twoFactor}
                  onChange={(e) => setTwoFactor(e.target.checked)}
                  className="h-5 w-5"
                />
              </div>
            </div>
          </div>

          {/* Privacy Settings */}
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
            <div className="mb-6 flex items-center gap-2">
              <Eye className="h-6 w-6 text-gray-900" />
              <h2 className="text-2xl font-bold text-gray-900">Privacy</h2>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Your profile visibility and data sharing preferences are managed here. MentiSync respects your privacy and keeps your information secure.
              </p>
              <button className="mt-4 rounded-lg bg-blue-600 px-6 py-2 font-medium text-white hover:bg-blue-700 transition-colors">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
