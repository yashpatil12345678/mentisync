import type { NextApiRequest, NextApiResponse } from 'next';
import { db } from '../../../lib/db';
import { jwtUtils } from '../../../lib/jwt';
import { cookieUtils } from '../../../lib/cookies';

interface SignupRequest {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: 'student' | 'mentor' | 'admin';
}

interface SignupResponse {
  success: boolean;
  message?: string;
  user?: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
  error?: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<SignupResponse>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { name, email, password, confirmPassword, role } = req.body as SignupRequest;

    // Validate required fields
    if (!name || !email || !password || !confirmPassword || !role) {
      return res.status(400).json({
        success: false,
        error: 'All fields are required',
      });
    }

    // Validate passwords match
    if (password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'Passwords do not match',
      });
    }

    // Create user
    const user = await db.createUser({
      name,
      email,
      password,
      role,
    });

    // Generate JWT token
    const token = jwtUtils.sign({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    // Set HTTP-only cookie
    cookieUtils.setToken(res, token);

    return res.status(201).json({
      success: true,
      message: 'Signup successful',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Signup failed';
    return res.status(400).json({
      success: false,
      error: message,
    });
  }
}
