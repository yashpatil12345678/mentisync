import type { NextApiRequest, NextApiResponse } from 'next';
import { db } from '../../../lib/db';
import { jwtUtils } from '../../../lib/jwt';
import { cookieUtils } from '../../../lib/cookies';

interface MeResponse {
  success: boolean;
  user?: {
    id: string;
    name: string;
    email: string;
    role: string;
    averageScore: number;
  };
  error?: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<MeResponse>
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    // Get token from cookie
    const token = cookieUtils.getToken(req);
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Unauthorized',
      });
    }

    // Verify token
    const payload = jwtUtils.verify(token);
    if (!payload) {
      return res.status(401).json({
        success: false,
        error: 'Invalid token',
      });
    }

    // Get user from database
    const user = await db.findUserById(payload.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found',
      });
    }

    return res.status(200).json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        averageScore: user.averageScore,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to get user info';
    return res.status(500).json({
      success: false,
      error: message,
    });
  }
}
