import type { NextApiRequest, NextApiResponse } from 'next';
import { cookieUtils } from '../../../lib/cookies';

interface LogoutResponse {
  success: boolean;
  message?: string;
  error?: string;
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<LogoutResponse>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    // Clear the authentication cookie
    cookieUtils.clearToken(res);

    return res.status(200).json({
      success: true,
      message: 'Logout successful',
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Logout failed';
    return res.status(500).json({
      success: false,
      error: message,
    });
  }
}
