import React, { useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { StatCard } from '../components/dashboard/StatCard';
import { PerformanceChart } from '../components/dashboard/PerformanceChart';
import { SessionCard } from '../components/dashboard/SessionCard';
import { AdaptiveAlertCard } from '../components/dashboard/AdaptiveAlertCard';
import { dataUtils } from '../utils/data';
import { Users, TrendingUp, Clock, Target } from 'lucide-react';

export default function StudentDashboard() {
  const { user } = useAuth();
  const performanceData = useMemo(() => dataUtils.getPerformanceData(), []);
  const sessions = useMemo(() => dataUtils.getSessions('student'), []);
  const stats = useMemo(
    () => dataUtils.getDashboardStats('student', user?.averageScore || 75),
    [user?.averageScore]
  );

  return (
    <ProtectedRoute allowedRoles={['student']}>
      <DashboardLayout title="Student Dashboard">
        <div className="space-y-8">
          {/* Adaptive Alert */}
          <AdaptiveAlertCard averageScore={user?.averageScore || 75} />

          {/* Stats Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Total Sessions"
              value={stats.totalSessions}
              icon={Clock}
              color="blue"
            />
            <StatCard
              label="Completed"
              value={stats.completedSessions}
              icon={TrendingUp}
              color="green"
              change={{
                value: 12,
                positive: true,
              }}
            />
            <StatCard
              label="Average Score"
              value={`${stats.averageScore}%`}
              icon={Target}
              color="purple"
            />
            <StatCard
              label="Progress"
              value={`${Math.round(stats.progress)}%`}
              icon={Users}
              color="orange"
            />
          </div>

          {/* Charts and Sessions */}
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Performance Chart */}
            <div className="lg:col-span-2">
              <PerformanceChart data={performanceData} />
            </div>

            {/* Quick Stats */}
            <div className="space-y-4">
              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900">Quick Stats</h3>
                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Mentors</span>
                    <span className="font-semibold text-gray-900">2</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Study Hours</span>
                    <span className="font-semibold text-gray-900">24h</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Streak</span>
                    <span className="font-semibold text-gray-900">5 days</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Rank</span>
                    <span className="font-semibold text-gray-900">#12</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Upcoming Sessions */}
          <div id="mentors">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Upcoming Sessions</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {sessions.slice(0, 3).map((session) => (
                <SessionCard
                  key={session.id}
                  session={session}
                />
              ))}
            </div>
          </div>

          {/* All Sessions */}
          <div id="progress">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">All Sessions</h2>
            <div className="space-y-3">
              {sessions.map((session) => (
                <SessionCard
                  key={session.id}
                  session={session}
                  variant="compact"
                />
              ))}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
