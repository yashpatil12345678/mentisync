import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { ProtectedRoute } from '../../components/ProtectedRoute';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Calendar, AlertCircle, CheckCircle, FileText } from 'lucide-react';

export default function AssignmentDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [submitted, setSubmitted] = useState(false);

  // Mock assignment data
  const assignment = {
    id: id || '1',
    title: 'Build a Todo List App',
    course: 'Advanced React Development',
    description: 'Create a fully functional todo list application with the following features: add, edit, delete, and filter tasks.',
    dueDate: '2024-03-15',
    submittedDate: submitted ? new Date().toLocaleDateString() : null,
    status: submitted ? 'submitted' : 'pending',
    points: 100,
    requirements: [
      'Create React component for todo list',
      'Implement add, edit, delete functionality',
      'Add filter options (all, active, completed)',
      'Style with CSS or Tailwind',
      'Write unit tests',
    ],
    rubric: [
      { criterion: 'Functionality', points: 40 },
      { criterion: 'Code Quality', points: 30 },
      { criterion: 'Testing', points: 20 },
      { criterion: 'UI/UX', points: 10 },
    ],
  };

  const daysUntilDue = Math.ceil(
    (new Date(assignment.dueDate).getTime() - new Date().getTime()) /
    (1000 * 60 * 60 * 24)
  );

  return (
    <ProtectedRoute>
      <DashboardLayout title="Assignment">
        <div className="max-w-4xl space-y-8">
          {/* Assignment Header */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <div className="mb-6 flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-2">{assignment.course}</p>
                <h2 className="text-3xl font-bold text-gray-900">{assignment.title}</h2>
              </div>
              {submitted ? (
                <div className="flex items-center gap-2 rounded-lg bg-green-50 px-4 py-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-green-700">Submitted</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 rounded-lg bg-orange-50 px-4 py-2">
                  <AlertCircle className="h-5 w-5 text-orange-600" />
                  <span className="font-medium text-orange-700">In Progress</span>
                </div>
              )}
            </div>

            <p className="text-gray-600 mb-6">{assignment.description}</p>

            <div className="mb-6 grid grid-cols-3 gap-4">
              <div className="rounded-lg bg-gray-50 p-4">
                <p className="text-xs text-gray-600">Due Date</p>
                <p className="font-semibold text-gray-900">
                  {new Date(assignment.dueDate).toLocaleDateString()}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {daysUntilDue > 0
                    ? `${daysUntilDue} days left`
                    : 'Overdue'}
                </p>
              </div>
              <div className="rounded-lg bg-gray-50 p-4">
                <p className="text-xs text-gray-600">Total Points</p>
                <p className="font-semibold text-gray-900">{assignment.points}</p>
              </div>
              <div className="rounded-lg bg-gray-50 p-4">
                <p className="text-xs text-gray-600">Submitted</p>
                <p className="font-semibold text-gray-900">
                  {submitted ? assignment.submittedDate : 'Not submitted'}
                </p>
              </div>
            </div>

            {!submitted && (
              <button
                onClick={() => setSubmitted(true)}
                className="rounded-lg bg-blue-600 px-6 py-2 font-semibold text-white hover:bg-blue-700 transition-colors"
              >
                Submit Assignment
              </button>
            )}
          </div>

          {/* Requirements */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <div className="mb-6 flex items-center gap-2">
              <FileText className="h-6 w-6 text-gray-900" />
              <h3 className="text-2xl font-bold text-gray-900">Requirements</h3>
            </div>
            <ul className="space-y-3">
              {assignment.requirements.map((req, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <div className="mt-1 h-2 w-2 rounded-full bg-blue-600 flex-shrink-0"></div>
                  <span className="text-gray-700">{req}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Rubric */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <h3 className="mb-6 text-2xl font-bold text-gray-900">Grading Rubric</h3>
            <div className="space-y-3">
              {assignment.rubric.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-lg bg-gray-50 p-4">
                  <p className="font-medium text-gray-900">{item.criterion}</p>
                  <p className="font-semibold text-gray-900">{item.points} points</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
