import React from 'react';
import { useRouter } from 'next/router';
import { ProtectedRoute } from '../../components/ProtectedRoute';
import { DashboardLayout } from '../../components/DashboardLayout';
import { BookOpen, Clock, Users, Star } from 'lucide-react';

export default function CourseDetail() {
  const router = useRouter();
  const { id } = router.query;

  // Mock course data
  const course = {
    id: id || '1',
    title: 'Advanced React Development',
    instructor: 'Sarah Chen',
    description: 'Learn advanced React patterns and best practices for building scalable applications.',
    duration: '12 weeks',
    level: 'Advanced',
    students: 342,
    rating: 4.8,
    lessons: 48,
    modules: [
      { id: 1, title: 'Hooks & State Management', lessons: 8 },
      { id: 2, title: 'Performance Optimization', lessons: 6 },
      { id: 3, title: 'Testing & Debugging', lessons: 10 },
      { id: 4, title: 'Real-world Projects', lessons: 24 },
    ],
  };

  return (
    <ProtectedRoute>
      <DashboardLayout title="Course">
        <div className="max-w-4xl space-y-8">
          {/* Course Header */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">{course.title}</h2>
            <p className="text-lg text-gray-600 mb-6">{course.description}</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="text-xs text-gray-600">Duration</p>
                  <p className="font-semibold text-gray-900">{course.duration}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="text-xs text-gray-600">Lessons</p>
                  <p className="font-semibold text-gray-900">{course.lessons}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="text-xs text-gray-600">Students</p>
                  <p className="font-semibold text-gray-900">{course.students}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                <div>
                  <p className="text-xs text-gray-600">Rating</p>
                  <p className="font-semibold text-gray-900">{course.rating}</p>
                </div>
              </div>
            </div>

            <button className="rounded-lg bg-blue-600 px-6 py-2 font-semibold text-white hover:bg-blue-700 transition-colors">
              Enroll Now
            </button>
          </div>

          {/* Course Modules */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Course Modules</h3>
            <div className="space-y-4">
              {course.modules.map((module) => (
                <div
                  key={module.id}
                  className="rounded-lg border border-gray-200 p-4 hover:shadow-sm transition-shadow cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-gray-900">{module.title}</h4>
                      <p className="text-sm text-gray-600">{module.lessons} lessons</p>
                    </div>
                    <div className="h-2 w-32 rounded-full bg-gray-200">
                      <div
                        className="h-2 rounded-full bg-blue-600"
                        style={{ width: '0%' }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Instructor */}
          <div className="rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">About the Instructor</h3>
            <div className="flex items-center gap-6">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600">
                <span className="text-2xl font-bold text-white">SC</span>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-900">{course.instructor}</h4>
                <p className="text-gray-600">Senior React Developer with 8+ years of experience</p>
                <button className="mt-3 rounded-lg bg-blue-50 px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-100 transition-colors">
                  Contact Instructor
                </button>
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
