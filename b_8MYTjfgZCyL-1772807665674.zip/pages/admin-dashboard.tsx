import React, { useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ProtectedRoute } from '../components/ProtectedRoute';
import { DashboardLayout } from '../components/DashboardLayout';
import { StatCard } from '../components/dashboard/StatCard';
import { PerformanceChart } from '../components/dashboard/PerformanceChart';
import { dataUtils } from '../utils/data';
import { Users, TrendingUp, BarChart3, Clock } from 'lucide-react';

export default function AdminDashboard() {
  const { user } = useAuth();
  const performanceData = useMemo(() => dataUtils.getPerformanceData(), []);

  return (
    <ProtectedRoute allowedRoles={['admin']}>
      <DashboardLayout title="Admin Dashboard">
        <div className="space-y-8">
          {/* Platform Overview Alert */}
          <div className="rounded-lg border border-green-200 bg-green-50 p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-green-100">
                <svg className="h-4 w-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-green-900">Platform Status: Healthy</h3>
                <p className="mt-1 text-sm text-green-800">All systems operational with optimal performance metrics.</p>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Total Users"
              value={347}
              icon={Users}
              color="blue"
              change={{
                value: 8,
                positive: true,
              }}
            />
            <StatCard
              label="Active Sessions"
              value={28}
              icon={Clock}
              color="green"
            />
            <StatCard
              label="Platform Growth"
              value="23%"
              icon={TrendingUp}
              color="purple"
              change={{
                value: 5,
                positive: true,
              }}
            />
            <StatCard
              label="Avg Performance"
              value="82%"
              icon={BarChart3}
              color="orange"
            />
          </div>

          {/* Charts and Breakdown */}
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Performance Trend */}
            <div className="lg:col-span-2">
              <PerformanceChart data={performanceData} />
            </div>

            {/* User Breakdown */}
            <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900">User Breakdown</h3>
              <div className="mt-6 space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-600">Students</p>
                    <span className="text-lg font-semibold text-gray-900">185</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-200">
                    <div className="h-2 rounded-full bg-blue-600" style={{ width: '53%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-600">Mentors</p>
                    <span className="text-lg font-semibold text-gray-900">95</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-200">
                    <div className="h-2 rounded-full bg-green-600" style={{ width: '27%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-600">Admins</p>
                    <span className="text-lg font-semibold text-gray-900">5</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-200">
                    <div className="h-2 rounded-full bg-purple-600" style={{ width: '1.4%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-600">Inactive</p>
                    <span className="text-lg font-semibold text-gray-900">62</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-200">
                    <div className="h-2 rounded-full bg-gray-400" style={{ width: '18%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div id="users">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">System Monitoring</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="font-semibold text-gray-900">Active Connections</h3>
                <p className="mt-2 text-3xl font-bold text-blue-600">156</p>
                <p className="mt-2 text-sm text-gray-600">Users currently online</p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="font-semibold text-gray-900">Sessions Today</h3>
                <p className="mt-2 text-3xl font-bold text-green-600">43</p>
                <p className="mt-2 text-sm text-gray-600">Completed mentoring sessions</p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="font-semibold text-gray-900">API Health</h3>
                <p className="mt-2 text-3xl font-bold text-purple-600">99.9%</p>
                <p className="mt-2 text-sm text-gray-600">Uptime this month</p>
              </div>

              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
                <h3 className="font-semibold text-gray-900">Response Time</h3>
                <p className="mt-2 text-3xl font-bold text-orange-600">145ms</p>
                <p className="mt-2 text-sm text-gray-600">Average API response</p>
              </div>
            </div>
          </div>

          {/* Recent Activity Log */}
          <div id="analytics">
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Recent Activity</h2>
            <div className="rounded-lg border border-gray-200 bg-white shadow-sm">
              <div className="divide-y divide-gray-200">
                {[
                  { action: 'New user registered', user: 'Emily Rodriguez', time: '5 minutes ago' },
                  { action: 'Session completed', user: 'John & Sarah', time: '12 minutes ago' },
                  { action: 'User reported issue', user: 'Alex Chen', time: '28 minutes ago' },
                  { action: 'New mentor joined', user: 'Dr. Michael Park', time: '1 hour ago' },
                  { action: 'System maintenance', user: 'Admin', time: '3 hours ago' },
                ].map((activity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                    <div>
                      <p className="font-medium text-gray-900">{activity.action}</p>
                      <p className="text-sm text-gray-600">{activity.user}</p>
                    </div>
                    <span className="text-sm text-gray-500">{activity.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
