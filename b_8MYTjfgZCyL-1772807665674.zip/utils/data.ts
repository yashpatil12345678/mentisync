import { Session, PerformanceData, DashboardStats } from '../types';

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor?: string;
  progress?: number;
  enrolledAt?: string;
  status: 'active' | 'completed' | 'pending';
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded' | 'reviewing';
  score?: number;
  course: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'session' | 'assignment' | 'message' | 'system';
  read: boolean;
  timestamp: string;
}

export const dataUtils = {
  /**
   * Get mock performance data for charts
   */
  getPerformanceData: (): PerformanceData[] => [
    { date: 'Jan', score: 65 },
    { date: 'Feb', score: 72 },
    { date: 'Mar', score: 68 },
    { date: 'Apr', score: 78 },
    { date: 'May', score: 82 },
    { date: 'Jun', score: 85 },
    { date: 'Jul', score: 88 },
    { date: 'Aug', score: 90 },
  ],

  /**
   * Get mock session data
   */
  getSessions: (role: 'student' | 'mentor'): Session[] => {
    if (role === 'student') {
      return [
        {
          id: '1',
          title: 'Career Development Discussion',
          date: '2024-03-15',
          duration: 60,
          status: 'completed',
          mentor: 'Sarah Mentor',
        },
        {
          id: '2',
          title: 'Project Feedback Review',
          date: '2024-03-22',
          duration: 45,
          status: 'scheduled',
          mentor: 'Sarah Mentor',
        },
        {
          id: '3',
          title: 'Technical Skills Assessment',
          date: '2024-03-10',
          duration: 90,
          status: 'completed',
          mentor: 'Sarah Mentor',
        },
        {
          id: '4',
          title: 'Goal Setting Workshop',
          date: '2024-02-28',
          duration: 75,
          status: 'completed',
          mentor: 'Sarah Mentor',
        },
      ];
    } else {
      return [
        {
          id: '1',
          title: 'Mentoring John Student',
          date: '2024-03-15',
          duration: 60,
          status: 'completed',
          student: 'John Student',
        },
        {
          id: '2',
          title: 'Mentoring John Student',
          date: '2024-03-22',
          duration: 45,
          status: 'scheduled',
          student: 'John Student',
        },
        {
          id: '3',
          title: 'Group Workshop Session',
          date: '2024-03-25',
          duration: 120,
          status: 'scheduled',
          student: 'Group',
        },
      ];
    }
  },

  /**
   * Get dashboard stats based on role and user data
   */
  getDashboardStats: (role: 'student' | 'mentor', averageScore: number = 75): DashboardStats => {
    if (role === 'student') {
      return {
        totalSessions: 12,
        completedSessions: 10,
        averageScore: averageScore,
        progress: (averageScore / 100) * 100,
      };
    } else {
      return {
        totalSessions: 24,
        completedSessions: 22,
        averageScore: averageScore,
        progress: (averageScore / 100) * 100,
      };
    }
  },

  /**
   * Get adaptive message based on average score
   */
  getAdaptiveMessage: (averageScore: number): { title: string; message: string; color: string } => {
    if (averageScore >= 90) {
      return {
        title: 'Outstanding Performance',
        message: 'You are excelling! Keep up the excellent work and continue pushing yourself.',
        color: 'bg-green-50',
      };
    } else if (averageScore >= 80) {
      return {
        title: 'Great Progress',
        message: 'You are performing well! Focus on key areas to reach excellence.',
        color: 'bg-blue-50',
      };
    } else if (averageScore >= 70) {
      return {
        title: 'Good Effort',
        message: 'You are on the right track. With focused practice, you can improve further.',
        color: 'bg-yellow-50',
      };
    } else {
      return {
        title: 'Areas for Growth',
        message: 'Let us work together to improve. Schedule a session with your mentor.',
        color: 'bg-orange-50',
      };
    }
  },

  /**
   * Get color for score visualization
   */
  getScoreColor: (score: number): string => {
    if (score >= 90) return '#10b981'; // green
    if (score >= 80) return '#3b82f6'; // blue
    if (score >= 70) return '#f59e0b'; // amber
    return '#ef4444'; // red
  },

  /**
   * Get status badge color
   */
  getStatusColor: (status: 'completed' | 'scheduled' | 'cancelled'): string => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  },
};
