import React from 'react';
import Link from 'next/link';
import { Bell, Settings, Menu, ChevronDown } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface NavbarProps {
  title: string;
  onMenuClick?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ title, onMenuClick }) => {
  const { user } = useAuth();

  return (
    <nav className="border-b border-gray-200 bg-white px-4 py-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        {/* Left side - Menu and Title */}
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden rounded-lg p-2 hover:bg-gray-100"
            aria-label="Toggle menu"
          >
            <Menu size={24} className="text-gray-600" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
        </div>

        {/* Right side icons */}
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <Link
            href="/notifications"
            className="relative rounded-lg p-2 text-gray-600 hover:bg-gray-100 transition-colors"
            title="Notifications"
          >
            <Bell size={20} />
            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500" />
          </Link>

          {/* Settings */}
          <Link
            href="/settings"
            className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 transition-colors"
            title="Settings"
          >
            <Settings size={20} />
          </Link>

          {/* User Profile */}
          <Link
            href="/profile"
            className="flex items-center gap-3 border-l border-gray-200 pl-4 hover:opacity-70 transition-opacity"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600">
              <span className="text-sm font-medium text-white">
                {user?.avatar || 'U'}
              </span>
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-gray-900">{user?.name}</p>
            </div>
            <ChevronDown size={16} className="hidden text-gray-600 sm:block" />
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
