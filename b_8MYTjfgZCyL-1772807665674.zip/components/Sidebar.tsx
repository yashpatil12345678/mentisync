import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAuth } from '../hooks/useAuth';
import {
  LayoutDashboard,
  Users,
  BarChart3,
  LogOut,
  X,
} from 'lucide-react';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ open, onClose }) => {
  const router = useRouter();
  const { user, logout } = useAuth();

  const getNavItems = () => {
    switch (user?.role) {
      case 'student':
        return [
          { href: '/student-dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { href: '/student-dashboard#mentors', label: 'My Mentors', icon: Users },
          { href: '/student-dashboard#progress', label: 'Progress', icon: BarChart3 },
        ];
      case 'mentor':
        return [
          { href: '/mentor-dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { href: '/mentor-dashboard#students', label: 'My Students', icon: Users },
          { href: '/mentor-dashboard#analytics', label: 'Analytics', icon: BarChart3 },
        ];
      case 'admin':
        return [
          { href: '/admin-dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { href: '/admin-dashboard#users', label: 'Users', icon: Users },
          { href: '/admin-dashboard#analytics', label: 'Analytics', icon: BarChart3 },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const handleNavClick = () => {
    onClose();
  };

  return (
    <>
      {/* Overlay for mobile */}
      {open && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-40 h-full w-64 transform bg-white shadow-lg transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Close Button for Mobile */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 lg:hidden p-2 hover:bg-gray-100 rounded-lg"
        >
          <X size={24} className="text-gray-600" />
        </button>

        {/* Logo/Brand */}
        <div className="border-b border-gray-200 p-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600">
              <span className="text-sm font-bold text-white">MS</span>
            </div>
            <span className="text-xl font-bold text-gray-900">MentiSync</span>
          </div>
        </div>

        {/* User Info */}
        <div className="border-b border-gray-200 p-4">
          <p className="text-sm font-medium text-gray-900">{user?.name}</p>
          <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-2 p-4">
          {navItems.map(({ href, label, icon: Icon }) => {
            const isActive = router.pathname === href.split('#')[0];
            return (
              <Link
                key={href}
                href={href}
                onClick={handleNavClick}
                className={`flex items-center gap-3 rounded-lg px-4 py-2 transition-colors ${
                  isActive
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Logout Button */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-gray-200 p-4">
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-lg px-4 py-2 text-gray-700 transition-colors hover:bg-gray-100"
          >
            <LogOut size={20} />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
