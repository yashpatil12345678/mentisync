import React from 'react';
import { AlertCircle, CheckCircle, Zap, TrendingUp } from 'lucide-react';
import { dataUtils } from '../../utils/data';

interface AdaptiveAlertCardProps {
  averageScore: number;
}

export const AdaptiveAlertCard: React.FC<AdaptiveAlertCardProps> = ({
  averageScore,
}) => {
  const adaptive = dataUtils.getAdaptiveMessage(averageScore);

  const getIcon = () => {
    if (averageScore >= 90) {
      return <CheckCircle className="h-6 w-6 text-green-600" />;
    } else if (averageScore >= 80) {
      return <TrendingUp className="h-6 w-6 text-blue-600" />;
    } else if (averageScore >= 70) {
      return <Zap className="h-6 w-6 text-yellow-600" />;
    }
    return <AlertCircle className="h-6 w-6 text-orange-600" />;
  };

  return (
    <div className={`rounded-lg border-l-4 p-4 ${adaptive.color}`}>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">{getIcon()}</div>
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">{adaptive.title}</h3>
          <p className="mt-1 text-sm text-gray-700">{adaptive.message}</p>
          <button className="mt-3 text-sm font-medium text-blue-600 transition-colors hover:text-blue-700">
            Learn More →
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdaptiveAlertCard;
