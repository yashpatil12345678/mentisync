import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import { PerformanceData } from '../../types';
import { dataUtils } from '../../utils/data';

interface PerformanceChartProps {
  data?: PerformanceData[];
  height?: number;
  showArea?: boolean;
}

export const PerformanceChart: React.FC<PerformanceChartProps> = ({
  data = [],
  height = 300,
  showArea = true,
}) => {
  const chartData = data.length > 0 ? data : [];

  if (chartData.length === 0) {
    return (
      <div className="flex h-full items-center justify-center rounded-lg border border-gray-200 bg-white p-6">
        <p className="text-gray-500">No data available</p>
      </div>
    );
  }

  const ChartComponent = showArea ? AreaChart : LineChart;
  const LineOrArea = showArea ? Area : Line;

  return (
    <div className="w-full rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
      <h3 className="mb-4 text-lg font-semibold text-gray-900">Performance Trend</h3>
      <ResponsiveContainer width="100%" height={height}>
        <ChartComponent data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="date" stroke="#6b7280" />
          <YAxis stroke="#6b7280" domain={[0, 100]} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1f2937',
              border: 'none',
              borderRadius: '8px',
              color: '#fff',
            }}
            formatter={(value) => [value, 'Score']}
          />
          {showArea ? (
            <Area
              type="monotone"
              dataKey="score"
              stroke="#3b82f6"
              fill="#93c5fd"
              fillOpacity={0.3}
              dot={{ fill: '#3b82f6', r: 4 }}
              activeDot={{ r: 6 }}
            />
          ) : (
            <Line
              type="monotone"
              dataKey="score"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={{ fill: '#3b82f6', r: 4 }}
              activeDot={{ r: 6 }}
            />
          )}
        </ChartComponent>
      </ResponsiveContainer>
    </div>
  );
};

export default PerformanceChart;
