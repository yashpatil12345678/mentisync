import React from 'react';
import Link from 'next/link';
import { Clock, User, Calendar } from 'lucide-react';
import { Session } from '../../types';
import { dataUtils } from '../../utils/data';

interface SessionCardProps {
  session: Session;
  variant?: 'default' | 'compact';
}

export const SessionCard: React.FC<SessionCardProps> = ({
  session,
  variant = 'default',
}) => {
  const statusColor = dataUtils.getStatusColor(session.status);
  const formattedDate = new Date(session.date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  if (variant === 'compact') {
    return (
      <div className="flex items-center justify-between rounded-lg border border-gray-200 bg-white p-4">
        <div>
          <p className="font-medium text-gray-900">{session.title}</p>
          <p className="text-sm text-gray-500">
            {session.mentor || session.student}
          </p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${statusColor}`}>
          {session.status}
        </span>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{session.title}</h3>
          <p className="text-sm text-gray-500">
            {session.mentor || session.student}
          </p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${statusColor}`}>
          {session.status}
        </span>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar size={16} className="text-gray-400" />
          <span>{formattedDate}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock size={16} className="text-gray-400" />
          <span>{session.duration} minutes</span>
        </div>
      </div>

      <Link
        href={`/assignments/${session.id}`}
        className="mt-4 block w-full rounded-lg bg-blue-50 px-4 py-2 text-center text-sm font-medium text-blue-700 transition-colors hover:bg-blue-100"
      >
        View Details
      </Link>
    </div>
  );
};

export default SessionCard;
